import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Brain, PenLine, Puzzle, Layers } from "lucide-react";

const games = [
  {
    id: "guess-form",
    title: "Угадай форму",
    desc: "Выбери правильную форму глагола из 4 вариантов",
    icon: Brain,
    color: "bg-primary/10 text-primary",
    path: "/games/guess-form",
    badge: "🧠 SRS",
  },
  {
    id: "write-form",
    title: "Напиши форму",
    desc: "Напиши форму на иврите — встроенная клавиатура",
    icon: PenLine,
    color: "bg-success/10 text-success",
    path: "/games/write-form",
    badge: "⌨️ Ввод",
  },
  {
    id: "guess-root",
    title: "Угадай корень",
    desc: "Определи трёхбуквенный корень (שורש) глагола",
    icon: Puzzle,
    color: "bg-streak/10 text-streak",
    path: "/games/guess-root",
    badge: "🧩 Корни",
  },
  {
    id: "guess-binyan",
    title: "Угадай биньян",
    desc: "К какому биньяну относится этот глагол?",
    icon: Layers,
    color: "bg-destructive/10 text-destructive",
    path: "/games/guess-binyan",
    badge: "🏗️ Биньян",
  },
];

export default function Games() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background pb-20 px-4 pt-8">
      <h1 className="text-2xl font-black text-foreground mb-2">Игры</h1>
      <p className="text-sm text-muted-foreground mb-6">Выберите режим для тренировки</p>
      <div className="grid grid-cols-2 gap-3">
        {games.map((game, i) => (
          <motion.button
            key={game.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate(game.path)}
            className="bg-card rounded-2xl p-4 text-left border border-border shadow-sm relative overflow-hidden"
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${game.color}`}>
              <game.icon className="w-5 h-5" />
            </div>
            <p className="font-bold text-foreground text-sm">{game.title}</p>
            <p className="text-xs text-muted-foreground mt-1 leading-snug">{game.desc}</p>
            <span className="inline-block mt-2 text-[10px] font-bold bg-muted text-muted-foreground rounded-full px-2 py-0.5">
              {game.badge}
            </span>
          </motion.button>
        ))}
      </div>

      {/* Tips */}
      <div className="mt-6 bg-card border border-border rounded-2xl p-4">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Как работает SRS</p>
        <p className="text-sm text-muted-foreground leading-relaxed">
          «Угадай форму» использует <span className="text-foreground font-semibold">умное повторение</span> — глаголы, которые вы знаете, появляются реже. Ошибки возвращают слово в начало очереди.
        </p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {["1 день", "3 дня", "7 дней", "14 дней", "30 дней"].map((d, i) => (
            <span key={i} className="text-[10px] font-bold bg-primary/10 text-primary rounded-full px-2 py-0.5">
              Ур.{i + 1} → {d}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
