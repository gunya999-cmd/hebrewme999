import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Volume2, ExternalLink, Star } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SEED_VERBS } from "@/data/verbs";
import { BINYAN_NAMES, PERSON_LABELS, TENSE_LABELS, ConjugationForm } from "@/types/verb";
import { useLearning } from "@/hooks/useLearning";

const TENSES = ["present", "past", "future", "imperative"] as const;

export default function VerbDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTense, setActiveTense] = useState<string>("present");
  const { progress, markLearned } = useLearning();

  const verb = SEED_VERBS.find((v) => v.id === id);
  if (!verb) return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <p className="text-muted-foreground">Глагол не найден</p>
    </div>
  );

  const p = progress[verb.id];
  const level = p?.level || 0;
  const conjugation = verb.conjugations;
  const activeForms: Record<string, ConjugationForm> | undefined = conjugation ? (conjugation as any)[activeTense] : undefined;

  const speak = (text: string) => {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "he-IL";
    speechSynthesis.speak(u);
  };

  const pealimUrl = `https://www.pealim.com/ru/search/?q=${encodeURIComponent(verb.infinitive_hebrew)}`;

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-primary px-4 pt-10 pb-6 rounded-b-[2rem]">
        <div className="flex items-center justify-between mb-3">
          <button onClick={() => navigate(-1)} className="text-primary-foreground/80">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <button
            onClick={() => markLearned(verb.id)}
            className={`flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold transition-colors ${
              level >= 1 ? "bg-success/20 text-success" : "bg-primary-foreground/20 text-primary-foreground/70"}`}
          >
            <Star className={`w-3.5 h-3.5 ${level >= 1 ? "fill-success" : ""}`} />
            {level >= 1 ? "Изучен" : "Отметить"}
          </button>
        </div>

        <div className="text-center">
          <h1 className="font-hebrew text-4xl font-bold text-primary-foreground mb-1">{verb.infinitive_hebrew}</h1>
          <p className="text-primary-foreground/80 font-medium text-lg">{verb.transcription_ru}</p>
          <p className="text-primary-foreground/60 text-sm mt-1">{verb.translation_ru}</p>

          <div className="flex items-center justify-center gap-2 mt-4 flex-wrap">
            <span className="bg-primary-foreground/20 rounded-full px-3 py-1 text-xs font-bold text-primary-foreground">
              Корень: <span className="font-hebrew">{verb.root}</span>
            </span>
            <span className="bg-primary-foreground/20 rounded-full px-3 py-1 text-xs font-bold text-primary-foreground">
              <span className="font-hebrew">{verb.binyan}</span> {BINYAN_NAMES[verb.binyan]}
            </span>
            {level > 0 && (
              <span className="bg-success/30 rounded-full px-3 py-1 text-xs font-bold text-primary-foreground flex items-center gap-1">
                {["", "Ур.1", "Ур.2", "Ур.3", "Ур.4", "★"][level]}
              </span>
            )}
          </div>

          {/* Level dots */}
          {level > 0 && (
            <div className="flex justify-center gap-1 mt-3">
              {Array.from({ length: 5 }).map((_, j) => (
                <div key={j} className={`w-2.5 h-2.5 rounded-full transition-colors ${j < level ? "bg-success" : "bg-primary-foreground/20"}`} />
              ))}
            </div>
          )}

          {/* Buttons row */}
          <div className="flex justify-center gap-3 mt-4">
            <button
              onClick={() => speak(verb.infinitive_hebrew)}
              className="bg-primary-foreground/20 rounded-full p-2.5 active:scale-90 transition-transform"
              title="Произнести"
            >
              <Volume2 className="w-5 h-5 text-primary-foreground" />
            </button>
            <a
              href={pealimUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-primary-foreground/20 rounded-full px-4 py-2 flex items-center gap-1.5 text-primary-foreground text-xs font-bold active:scale-90 transition-transform"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Pealim
            </a>
          </div>
        </div>
      </div>

      {/* Conjugation */}
      {conjugation ? (
        <div className="px-4 mt-6">
          {/* Tense tabs */}
          <div className="flex gap-1 bg-muted rounded-xl p-1 mb-4">
            {TENSES.map((t) => (
              <button key={t} onClick={() => setActiveTense(t)}
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${activeTense === t ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}>
                {TENSE_LABELS[t]}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div key={activeTense} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.2 }} className="space-y-2">
              {activeForms && Object.entries(activeForms).map(([person, form]) => (
                <button key={person} onClick={() => speak(form.hebrew)}
                  className="w-full bg-card rounded-xl p-3.5 flex items-center gap-3 border border-border shadow-sm active:scale-[0.98] transition-transform text-left">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-primary leading-tight text-center">{PERSON_LABELS[person]}</span>
                  </div>
                  <div className="flex-1">
                    <span className="font-hebrew text-foreground font-bold text-lg">{form.hebrew}</span>
                    <div className="flex gap-2 mt-0.5 flex-wrap">
                      <span className="text-sm text-muted-foreground">{form.transcription}</span>
                      <span className="text-sm text-muted-foreground/60">— {form.translation}</span>
                    </div>
                  </div>
                  <Volume2 className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                </button>
              ))}
            </motion.div>
          </AnimatePresence>

          {/* Pealim promo */}
          <a href={pealimUrl} target="_blank" rel="noopener noreferrer"
            className="mt-4 flex items-center justify-center gap-2 bg-card border border-border rounded-xl p-3 text-sm text-muted-foreground hover:border-primary transition-colors">
            <ExternalLink className="w-4 h-4" />
            Полное спряжение и примеры на Pealim.com →
          </a>
        </div>
      ) : (
        <div className="px-4 mt-6 space-y-4">
          <div className="bg-card rounded-2xl p-5 border border-border">
            <p className="text-sm text-muted-foreground font-medium mb-3">Спряжение этого глагола доступно на Pealim:</p>
            <a href={pealimUrl} target="_blank" rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-xl p-3 font-bold text-sm active:scale-95 transition-transform">
              <ExternalLink className="w-4 h-4" />
              Открыть на Pealim.com
            </a>
          </div>
        </div>
      )}
    </div>
  );
}
