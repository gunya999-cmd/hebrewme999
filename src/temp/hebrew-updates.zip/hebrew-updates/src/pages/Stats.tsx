import { motion } from "framer-motion";
import { Trophy, TrendingUp, Calendar, Target } from "lucide-react";
import { useLearning } from "@/hooks/useLearning";
import { SEED_VERBS } from "@/data/verbs";
import { BINYAN_NAMES, Binyan } from "@/types/verb";

const ALL_BINYANIM = Object.keys(BINYAN_NAMES) as Binyan[];

const LEVEL_COLORS = ["bg-muted", "bg-blue-400/60", "bg-blue-500/70", "bg-blue-600/80", "bg-primary", "bg-success"];
const LEVEL_LABELS = ["Новые", "Ур. 1", "Ур. 2", "Ур. 3", "Ур. 4", "Освоено"];

export default function Stats() {
  const { progress, stats, learnedCount, masteredCount } = useLearning();
  const total = SEED_VERBS.length;
  const overallPct = Math.round((learnedCount / total) * 100);

  // Per binyan
  const binyanStats = ALL_BINYANIM.map((b) => {
    const verbsInBinyan = SEED_VERBS.filter((v) => v.binyan === b);
    const done = verbsInBinyan.filter((v) => (progress[v.id]?.level || 0) >= 1).length;
    const mastered = verbsInBinyan.filter((v) => (progress[v.id]?.level || 0) >= 5).length;
    return { binyan: b, total: verbsInBinyan.length, done, mastered, pct: verbsInBinyan.length ? Math.round((done / verbsInBinyan.length) * 100) : 0 };
  });

  // Level distribution
  const levelDist = [0, 1, 2, 3, 4, 5].map((l) => ({
    level: l,
    count: SEED_VERBS.filter((v) => (progress[v.id]?.level || 0) === l).length,
  }));

  // Most practiced verbs
  const topVerbs = SEED_VERBS
    .filter((v) => progress[v.id]?.correctCount)
    .sort((a, b) => (progress[b.id]?.correctCount || 0) - (progress[a.id]?.correctCount || 0))
    .slice(0, 5);

  // Struggling verbs
  const hardVerbs = SEED_VERBS
    .filter((v) => progress[v.id]?.wrongCount && progress[v.id].wrongCount > 0)
    .sort((a, b) => (progress[b.id]?.wrongCount || 0) - (progress[a.id]?.wrongCount || 0))
    .slice(0, 5);

  return (
    <div className="min-h-screen bg-background pb-20 px-4 pt-8">
      <h1 className="text-2xl font-black text-foreground mb-6">Прогресс</h1>

      {/* Overall */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="bg-primary rounded-2xl p-5 mb-4 text-center">
        <p className="text-primary-foreground/70 text-sm font-medium mb-1">Общий прогресс</p>
        <p className="text-5xl font-black text-primary-foreground">{overallPct}%</p>
        <p className="text-primary-foreground/80 text-sm mt-1">{learnedCount} из {total} глаголов</p>
        <div className="mt-3 h-2 bg-primary-foreground/20 rounded-full overflow-hidden">
          <div className="h-full bg-primary-foreground rounded-full transition-all duration-700" style={{ width: `${overallPct}%` }} />
        </div>
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-primary-foreground/10 rounded-xl p-2 text-center">
            <p className="text-xl font-black text-primary-foreground">{stats.streak}</p>
            <p className="text-[10px] text-primary-foreground/70">Серия 🔥</p>
          </div>
          <div className="bg-primary-foreground/10 rounded-xl p-2 text-center">
            <p className="text-xl font-black text-primary-foreground">{masteredCount}</p>
            <p className="text-[10px] text-primary-foreground/70">Освоено ⭐</p>
          </div>
          <div className="bg-primary-foreground/10 rounded-xl p-2 text-center">
            <p className="text-xl font-black text-primary-foreground">{stats.reviewed}</p>
            <p className="text-[10px] text-primary-foreground/70">Сегодня ✓</p>
          </div>
        </div>
      </motion.div>

      {/* Level distribution */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
        className="bg-card border border-border rounded-2xl p-4 mb-4">
        <p className="text-sm font-black text-foreground mb-3 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-primary" /> Распределение по уровням
        </p>
        <div className="space-y-2">
          {levelDist.map(({ level, count }) => {
            const pct = total ? Math.round((count / total) * 100) : 0;
            return (
              <div key={level} className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground w-12 text-right">{LEVEL_LABELS[level]}</span>
                <div className="flex-1 h-5 bg-muted rounded-full overflow-hidden">
                  <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.6, delay: level * 0.05 }}
                    className={`h-full rounded-full ${LEVEL_COLORS[level]}`} />
                </div>
                <span className="text-xs font-bold text-foreground w-8">{count}</span>
              </div>
            );
          })}
        </div>
      </motion.div>

      {/* Per binyan */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
        className="bg-card border border-border rounded-2xl p-4 mb-4">
        <p className="text-sm font-black text-foreground mb-3 flex items-center gap-2">
          <Target className="w-4 h-4 text-primary" /> По биньянам
        </p>
        <div className="space-y-3">
          {binyanStats.map(({ binyan, total: t, done, pct }) => (
            <div key={binyan}>
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-1.5">
                  <span className="font-hebrew font-bold text-primary text-sm">{binyan}</span>
                  <span className="text-xs text-muted-foreground">{BINYAN_NAMES[binyan]}</span>
                </div>
                <span className="text-xs font-bold text-muted-foreground">{done}/{t}</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.6 }}
                  className="h-full bg-primary rounded-full" />
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Top verbs */}
      {topVerbs.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="bg-card border border-border rounded-2xl p-4 mb-4">
          <p className="text-sm font-black text-foreground mb-3 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-yellow-500" /> Лучше всего знаете
          </p>
          <div className="space-y-2">
            {topVerbs.map((v) => (
              <div key={v.id} className="flex items-center justify-between">
                <div>
                  <span className="font-hebrew font-bold text-foreground">{v.infinitive_hebrew}</span>
                  <span className="text-xs text-muted-foreground ml-2">{v.translation_ru}</span>
                </div>
                <span className="text-xs font-bold text-success bg-success/10 rounded-full px-2 py-0.5">
                  ✓ {progress[v.id]?.correctCount}
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Hard verbs */}
      {hardVerbs.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
          className="bg-card border border-border rounded-2xl p-4">
          <p className="text-sm font-black text-foreground mb-3 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-destructive" /> Требуют внимания
          </p>
          <div className="space-y-2">
            {hardVerbs.map((v) => (
              <div key={v.id} className="flex items-center justify-between">
                <div>
                  <span className="font-hebrew font-bold text-foreground">{v.infinitive_hebrew}</span>
                  <span className="text-xs text-muted-foreground ml-2">{v.translation_ru}</span>
                </div>
                <span className="text-xs font-bold text-destructive bg-destructive/10 rounded-full px-2 py-0.5">
                  ✗ {progress[v.id]?.wrongCount}
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}
