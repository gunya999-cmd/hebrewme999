import { useState, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, CheckCircle2, XCircle, Delete } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { SEED_VERBS } from "@/data/verbs";
import { PERSON_LABELS, ConjugationForm } from "@/types/verb";
import { useLearning } from "@/hooks/useLearning";

// Ивритская клавиатура
const HEBREW_ROWS = [
  ["ק","ר","א","ט","ו","ן","ם","פ"],
  ["ש","ד","ג","כ","ע","י","ח","ל","ך","ף"],
  ["ז","ס","ב","ה","נ","מ","צ","ת","ץ"],
];

const TENSE_RU: Record<string, string> = { present: "настоящее", past: "прошедшее", future: "будущее" };

interface Question {
  verbId: string;
  verbHebrewInf: string;
  verbTranslation: string;
  person: string;
  personLabel: string;
  tense: string;
  correctAnswer: ConjugationForm;
}

function generateQuestions(verbPool: typeof SEED_VERBS, count: number): Question[] {
  const withConj = verbPool.filter((v) => v.conjugations);
  if (!withConj.length) return [];
  const tenses = ["present", "past", "future"] as const;
  return Array.from({ length: count }, () => {
    const verb = withConj[Math.floor(Math.random() * withConj.length)];
    const tense = tenses[Math.floor(Math.random() * tenses.length)];
    const forms = (verb.conjugations as any)[tense] as Record<string, ConjugationForm>;
    const persons = Object.keys(forms);
    const person = persons[Math.floor(Math.random() * persons.length)];
    return { verbId: verb.id, verbHebrewInf: verb.infinitive_hebrew, verbTranslation: verb.translation_ru, person, personLabel: PERSON_LABELS[person] || person, tense, correctAnswer: forms[person] };
  });
}

function normalize(s: string) { return s.replace(/[\u05B0-\u05C7]/g, "").trim(); }

export default function WriteFormGame() {
  const navigate = useNavigate();
  const { markCorrect, markWrong, getDueVerbs } = useLearning();
  const dueVerbs = getDueVerbs();
  const [questions] = useState(() => generateQuestions(dueVerbs, 10));
  const [idx, setIdx] = useState(0);
  const [input, setInput] = useState("");
  const [checked, setChecked] = useState<"correct" | "wrong" | null>(null);
  const [score, setScore] = useState(0);

  const question = questions[idx];
  const isFinished = idx >= questions.length;

  const pressKey = (k: string) => { if (!checked) setInput((p) => k + p); };
  const backspace = () => { if (!checked) setInput((p) => p.slice(1)); };

  const check = useCallback(() => {
    if (!input || checked) return;
    const correct = normalize(input) === normalize(question.correctAnswer.hebrew);
    setChecked(correct ? "correct" : "wrong");
    if (correct) { setScore((s) => s + 1); markCorrect(question.verbId); }
    else { markWrong(question.verbId); }
    setTimeout(() => { setChecked(null); setInput(""); setIdx((i) => i + 1); }, 1800);
  }, [input, checked, question, markCorrect, markWrong]);

  const skip = () => { setChecked(null); setInput(""); setIdx((i) => i + 1); };

  if (!questions.length) return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6 text-center">
      <div><p className="text-muted-foreground mb-4">Нет глаголов для игры</p>
      <button onClick={() => navigate("/games")} className="px-6 py-3 bg-primary text-primary-foreground rounded-xl font-bold">К играм</button></div>
    </div>
  );

  if (isFinished) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
        <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 300, damping: 20 }} className="text-center w-full max-w-sm">
          <div className="text-6xl mb-4">{score >= 7 ? "✍️🎉" : "✍️💪"}</div>
          <h2 className="text-3xl font-black text-foreground mb-2">{score} из {questions.length}</h2>
          <p className="text-muted-foreground mb-8">{score >= 7 ? "Отличное написание!" : "Практика делает мастера!"}</p>
          <div className="flex gap-3">
            <button onClick={() => navigate("/games")} className="flex-1 py-3 bg-muted text-foreground rounded-xl font-bold">К играм</button>
            <button onClick={() => { setIdx(0); setScore(0); setInput(""); }} className="flex-1 py-3 bg-primary text-primary-foreground rounded-xl font-bold">Ещё раз</button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-4 px-4 pt-8 flex flex-col">
      {/* Top bar */}
      <div className="flex items-center gap-3 mb-4">
        <button onClick={() => navigate("/games")} className="text-muted-foreground"><ArrowLeft className="w-6 h-6" /></button>
        <div className="flex-1 bg-muted rounded-full h-2.5 overflow-hidden">
          <motion.div className="h-full bg-success rounded-full" animate={{ width: `${(idx / questions.length) * 100}%` }} transition={{ duration: 0.3 }} />
        </div>
        <span className="text-sm font-bold text-muted-foreground">{idx + 1}/{questions.length}</span>
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={idx} initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="flex-1 flex flex-col">
          {/* Question */}
          <div className="text-center mb-4">
            <p className="text-sm text-muted-foreground font-medium mb-1">
              Напишите форму: {TENSE_RU[question.tense]} — <span className="text-primary font-bold">{question.personLabel}</span>
            </p>
            <h2 className="font-hebrew text-3xl font-bold text-foreground">{question.verbHebrewInf}</h2>
            <p className="text-base text-muted-foreground">{question.verbTranslation}</p>
          </div>

          {/* Input display */}
          <div className={`rounded-2xl border-2 p-4 text-center mb-3 transition-colors ${
            checked === "correct" ? "border-success bg-success/10" :
            checked === "wrong" ? "border-destructive bg-destructive/10" :
            "border-border bg-card"}`}>
            <p className="font-hebrew text-4xl font-bold text-foreground min-h-[48px] tracking-widest" dir="rtl">
              {input || <span className="text-muted-foreground/30">הכנס תשובה</span>}
            </p>
            {checked === "correct" && (
              <div className="flex items-center justify-center gap-2 mt-2">
                <CheckCircle2 className="w-5 h-5 text-success" />
                <span className="text-success font-bold text-sm">Правильно! {question.correctAnswer.transcription}</span>
              </div>
            )}
            {checked === "wrong" && (
              <div className="mt-2">
                <div className="flex items-center justify-center gap-2">
                  <XCircle className="w-5 h-5 text-destructive" />
                  <span className="text-destructive font-bold text-sm">Ошибка</span>
                </div>
                <p className="text-sm text-foreground mt-1">
                  Правильно: <span className="font-hebrew font-bold">{question.correctAnswer.hebrew}</span> — {question.correctAnswer.transcription}
                </p>
              </div>
            )}
          </div>

          {/* Hebrew keyboard */}
          <div className="space-y-2 mb-3">
            {HEBREW_ROWS.map((row, ri) => (
              <div key={ri} className="flex justify-center gap-1.5">
                {row.map((k) => (
                  <button key={k} onClick={() => pressKey(k)} disabled={!!checked}
                    className="w-9 h-10 bg-card border border-border rounded-lg font-hebrew font-bold text-foreground text-lg shadow-sm active:scale-95 transition-transform disabled:opacity-40">
                    {k}
                  </button>
                ))}
              </div>
            ))}
            <div className="flex justify-center gap-2 mt-1">
              <button onClick={backspace} disabled={!!checked}
                className="px-4 h-10 bg-muted border border-border rounded-lg text-muted-foreground shadow-sm active:scale-95 transition-transform disabled:opacity-40 flex items-center gap-1">
                <Delete className="w-4 h-4" />
              </button>
              <button onClick={check} disabled={!input || !!checked}
                className="flex-1 h-10 bg-primary text-primary-foreground rounded-lg font-bold text-sm shadow-sm active:scale-95 transition-transform disabled:opacity-40">
                Проверить
              </button>
              <button onClick={skip} disabled={!!checked}
                className="px-4 h-10 bg-muted border border-border rounded-lg text-muted-foreground text-sm shadow-sm active:scale-95 transition-transform disabled:opacity-40">
                Пропустить
              </button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
