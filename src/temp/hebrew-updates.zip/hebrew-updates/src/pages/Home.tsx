import { Flame, Target, BookCheck, Sparkles, Clock, Trophy } from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import ProgressCircle from "@/components/ProgressCircle";
import { useLearning } from "@/hooks/useLearning";
import { SEED_VERBS } from "@/data/verbs";

export default function Home() {
  const navigate = useNavigate();
  const { stats, learnedCount, masteredCount, getDueCount } = useLearning();
  const totalVerbs = SEED_VERBS.length;
  const dueCount = getDueCount();

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-primary px-6 pt-12 pb-8 rounded-b-[2rem]">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-black text-primary-foreground">Иврит Глаголы</h1>
            <p className="text-primary-foreground/70 text-sm font-medium">300 глаголов за 30 дней</p>
          </div>
          <div className="flex items-center gap-1 bg-primary-foreground/20 rounded-full px-3 py-1.5">
            <Flame className="w-5 h-5 text-streak" />
            <span className="text-primary-foreground font-bold text-lg">{stats.streak}</span>
          </div>
        </div>

        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
          className="flex justify-center"
        >
          <ProgressCircle current={learnedCount} total={totalVerbs} />
        </motion.div>
      </div>

      {/* Daily Stats */}
      <div className="px-6 -mt-4">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-card rounded-2xl shadow-lg p-5 grid grid-cols-4 gap-3"
        >
          <div className="text-center">
            <Sparkles className="w-5 h-5 mx-auto mb-1 text-primary" />
            <p className="text-2xl font-black text-foreground">{stats.newLearned}</p>
            <p className="text-[10px] text-muted-foreground font-medium">Новых</p>
          </div>
          <div className="text-center">
            <BookCheck className="w-5 h-5 mx-auto mb-1 text-success" />
            <p className="text-2xl font-black text-foreground">{stats.reviewed}</p>
            <p className="text-[10px] text-muted-foreground font-medium">Повторено</p>
          </div>
          <div className="text-center">
            <Clock className="w-5 h-5 mx-auto mb-1 text-streak" />
            <p className="text-2xl font-black text-foreground">{dueCount}</p>
            <p className="text-[10px] text-muted-foreground font-medium">К повтор.</p>
          </div>
          <div className="text-center">
            <Trophy className="w-5 h-5 mx-auto mb-1 text-yellow-500" />
            <p className="text-2xl font-black text-foreground">{masteredCount}</p>
            <p className="text-[10px] text-muted-foreground font-medium">Освоено</p>
          </div>
        </motion.div>
      </div>

      {/* CTA — due count badge */}
      <div className="px-6 mt-6">
        <motion.button
          whileTap={{ scale: 0.95 }}
          whileHover={{ scale: 1.02 }}
          onClick={() => navigate("/games/guess-form")}
          className="w-full bg-success text-success-foreground font-bold text-lg py-4 rounded-2xl shadow-lg shadow-success/30 active:shadow-md transition-shadow relative"
        >
          🎯 Начать урок
          {dueCount > 0 && (
            <span className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/30 rounded-full px-2.5 py-0.5 text-sm font-black">
              {dueCount}
            </span>
          )}
        </motion.button>
      </div>

      {/* Quick Actions */}
      <div className="px-6 mt-4 grid grid-cols-2 gap-3">
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate("/dictionary")}
          className="bg-card rounded-2xl p-4 shadow-sm text-left border border-border"
        >
          <BookCheck className="w-6 h-6 text-primary mb-2" />
          <p className="font-bold text-foreground text-sm">Словарь</p>
          <p className="text-xs text-muted-foreground">{totalVerbs} глаголов</p>
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate("/games")}
          className="bg-card rounded-2xl p-4 shadow-sm text-left border border-border"
        >
          <Sparkles className="w-6 h-6 text-streak mb-2" />
          <p className="font-bold text-foreground text-sm">Игры</p>
          <p className="text-xs text-muted-foreground">4 режима</p>
        </motion.button>
      </div>

      {/* SRS level legend */}
      <div className="px-6 mt-5">
        <p className="text-xs text-muted-foreground font-semibold mb-3 uppercase tracking-wide">Уровни запоминания</p>
        <div className="bg-card border border-border rounded-2xl p-4 space-y-2">
          {[
            { level: 0, label: "Новый", color: "bg-muted", next: "Нет данных" },
            { level: 1, label: "Знаком", color: "bg-primary/40", next: "Повтор через 1 день" },
            { level: 2, label: "Учу", color: "bg-primary/60", next: "Повтор через 3 дня" },
            { level: 3, label: "Знаю", color: "bg-primary/80", next: "Повтор через 7 дней" },
            { level: 4, label: "Уверен", color: "bg-primary", next: "Повтор через 14 дней" },
            { level: 5, label: "Освоен", color: "bg-success", next: "Повтор через 30 дней" },
          ].map(({ level, label, color, next }) => (
            <div key={level} className="flex items-center gap-3">
              <div className="flex gap-0.5">
                {Array.from({ length: 5 }).map((_, j) => (
                  <div key={j} className={`w-2 h-2 rounded-full ${j < level ? color : "bg-muted"}`} />
                ))}
              </div>
              <span className="text-xs font-bold text-foreground w-16">{label}</span>
              <span className="text-xs text-muted-foreground">{next}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
